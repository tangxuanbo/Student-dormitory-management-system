package com.util;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.VerticalAlignment;


public final class ExcelUtil {

	private ExcelUtil() {
	}

	public static void out(String filename, String[] titleA, String[] titleKeyA, List<Map<String, Object>> dataList, HttpServletResponse response) {
        HSSFWorkbook workbook = new HSSFWorkbook();
        HSSFSheet sheet = workbook.createSheet();
        //设置列宽
        sheet.setDefaultColumnWidth((short) 18);
        //创建第一行的对象，第一行一般用于填充标题内容。从第二行开始一般是数据
        HSSFRow row = sheet.createRow(0);
        row.setHeight((short) 500);
        //标题单元格样式
		// 定义单元格的样式
		HSSFCellStyle cellStyle = workbook.createCellStyle();
		// 设置字体样式，13号，加粗
		HSSFFont font1 = workbook.createFont();
		font1.setFontHeightInPoints((short) 14);
		font1.setBold(true);
		cellStyle.setFont(font1);
		// 设置水平居中
		cellStyle.setAlignment(HorizontalAlignment.CENTER);
		cellStyle.setVerticalAlignment(VerticalAlignment.CENTER);
		
		cellStyle.setBorderBottom(BorderStyle.THIN);// 下边框
		cellStyle.setBorderLeft(BorderStyle.THIN);// 左边框
		cellStyle.setBorderRight(BorderStyle.THIN);// 右边框
		cellStyle.setBorderTop(BorderStyle.THIN);// 上边框
		
        for (short i = 0; i < titleA.length; i++) {
            //创建单元格，每行多少数据就创建多少个单元格
            HSSFCell cell = row.createCell(i);
            HSSFRichTextString text = new HSSFRichTextString(titleA[i]);
            //给单元格设置内容
            cell.setCellValue(text);
            cell.setCellStyle(cellStyle);
        }

        //数据单元格样式
 		HSSFCellStyle cellStyle2 = workbook.createCellStyle();
 		// 设置字体样式，13号，加粗
 		HSSFFont font2 = workbook.createFont();
 		font2.setFontHeightInPoints((short) 12);
 		cellStyle2.setFont(font2);
 		// 设置水平居中
 		cellStyle2.setAlignment(HorizontalAlignment.CENTER);
 		cellStyle2.setVerticalAlignment(VerticalAlignment.CENTER);
 		cellStyle2.setBorderBottom(BorderStyle.THIN);// 下边框
 		cellStyle2.setBorderLeft(BorderStyle.THIN);// 左边框
 		cellStyle2.setBorderRight(BorderStyle.THIN);// 右边框
 		cellStyle2.setBorderTop(BorderStyle.THIN);// 上边框
        
        //遍历集合，将每个集合元素对象的每个值填充到单元格中
       for(int i=0;i<dataList.size();i++){
    	   Map<String, Object> dMap = dataList.get(i);
    	   //从第二行开始填充数据
           row = sheet.createRow(i+1);
           row.setHeight((short) 300);
    	   for(int j=0; j<titleKeyA.length; j++){
    		   HSSFCell cell = row.createCell(j);
               HSSFRichTextString richString = new HSSFRichTextString(MapUtil.isContains(dMap, titleKeyA[j])?String.valueOf(dMap.get(titleKeyA[j])):"");
               cell.setCellValue(richString);
               cell.setCellStyle(cellStyle2);
    	   }
       }

       response.setContentType("application/octet-stream");
       try {
    	   response.setHeader("Content-Disposition", "attachment;fileName=" + new String(filename.getBytes("gbk"), "ISO-8859-1") + ".xls");
       } catch (Exception e) {
    	   e.printStackTrace();
       }
       try {
            response.flushBuffer();
       } catch (IOException e) {
            e.printStackTrace();
       }
       //将workbook中的内容写入输出流中
       try {
    	   workbook.write(response.getOutputStream());
       } catch (Exception e) {
    	   e.printStackTrace();
       }
	}
	
	
}