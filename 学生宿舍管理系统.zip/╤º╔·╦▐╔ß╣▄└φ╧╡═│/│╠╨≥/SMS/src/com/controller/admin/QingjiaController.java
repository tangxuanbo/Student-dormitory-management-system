package com.controller.admin;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.core.AbstractRestController;
import com.core.Page;
import com.dao.CmmDao;
import com.util.DateUtil;
import com.util.ExcelUtil;
import com.util.MapUtil;
import com.util.WebUtils;

@Controller
@RequestMapping("admin/qingjia/*")
public class QingjiaController extends AbstractRestController{	
	@Autowired
	CmmDao dao;
	
	private String tbNm = "qingjia";
	
	@RequestMapping(value = "excelOut")
	public void excelOut(@RequestParam Map<String, Object> pMap, HttpServletRequest request, HttpServletResponse response){
		pMap.put("tbNm", tbNm);
		Page page = dao.getPage(pMap);
		page.setPageSize(10000);
		List<Map<String, Object>> dataList = page.getDataList();
		if (dataList!=null) {
			for(Map<String, Object> map : dataList) {
				map.put("statusNm", dao.getCodeNm("STATUS", map.get("status").toString()));
				map.put("classidNm", dao.getFieldValById(map.get("classid").toString(), "name", "class"));
				map.put("iuidNm", dao.getUsername(map.get("iuid")));
			}
		}
		String[] titleA = new String[] {"宿舍","姓名","请假日期","说明","状态"};
		String[] titleKeyA = new String[] {"classidNm","iuidNm","ymd","descr","statusNm"};
		ExcelUtil.out("幼儿信息", titleA, titleKeyA, dataList, response);
	}
	
	@RequestMapping(value = "getPageList")
	@ResponseBody
	public String getPageList(@RequestParam Map<String, Object> pMap, HttpServletRequest request){
		pMap.put("tbNm", tbNm);
		Page page = dao.getPage(pMap);
		List<Map<String, Object>> dataList = page.getDataList();
		if (dataList!=null) {
			for(Map<String, Object> map : dataList) {
				map.put("statusNm", dao.getCodeNm("STATUS", map.get("status").toString()));
				map.put("classidNm", dao.getFieldValById(map.get("classid").toString(), "name", "class"));
				map.put("iuidNm", dao.getUsername(map.get("iuid")));
			}
		}
		return WebUtils.responseDataToJson(page);
	}
	
	@RequestMapping(value = "getMyPageList")
	@ResponseBody
	public String getMyPageList(@RequestParam Map<String, Object> pMap, HttpServletRequest request){
		pMap.put("tbNm", tbNm);
		pMap.put("yn", "Y");
		if (MapUtil.isContains(pMap, "name")) {
			pMap.put("where", " name like '%" + pMap.get("name") + "%'");
			pMap.put("name", "");
		}
		pMap.put("iuid", request.getSession().getAttribute("uid").toString());
		Page page = dao.getPage(pMap);
		List<Map<String, Object>> dataList = page.getDataList();
		if (dataList!=null) {
			for(Map<String, Object> map : dataList) {
				map.put("statusNm", dao.getCodeNm("STATUS", map.get("status").toString()));
				map.put("iuidNm", dao.getUsername(map.get("iuid")));
			}
		}
		return WebUtils.responseDataToJson(page);
	}
	
	@RequestMapping(value = "add")
	@ResponseBody
	public String add(@RequestParam Map<String, Object> pMap, HttpServletRequest request){
		String uid = request.getSession().getAttribute("uid").toString();
		Map<String, Object> userinfo = dao.getUserInfo(uid);
		pMap.put("classid", userinfo.get("classid"));
		List<Map<String, Object>> selList = dao.getList("select 1 from qingjia where iuid='"+uid+"' and ymd='"+pMap.get("ymd")+"'");
		if (selList.size() > 0) {
			return WebUtils.errorResp("考勤已存在");
		}
		pMap.put("iuid", request.getSession().getAttribute("uid"));
		dao.add(pMap, this.tbNm);
		return WebUtils.successResp(null,"操作成功");
	}
	
	@RequestMapping(value = "getInfo")
	@ResponseBody
	public String getInfo(@RequestParam Map<String, Object> pMap, HttpServletRequest request){
		Map<String, Object> info = dao.getInfoById(String.valueOf(pMap.get("id")), this.tbNm);
		String rtStr = JSON.toJSONString(info);
		return rtStr;
	}
	
	@RequestMapping(value = "getList")
	@ResponseBody
	public String getList(@RequestParam Map<String, Object> pMap, HttpServletRequest request){
		pMap.put("tbNm", tbNm);
		pMap.put("order by", " id desc");
		List<Map<String, Object>> dataList = dao.getList(pMap, tbNm);
		return JSON.toJSONString(dataList);
	}
	
	@RequestMapping(value = "update")
	@ResponseBody
	public String update(@RequestParam Map<String, Object> pMap, HttpServletRequest request){
		if (!MapUtil.isContains(pMap, "status")) {
			String uid = request.getSession().getAttribute("uid").toString();
			pMap.put("classid", dao.getFieldValById(uid, "classid", "userinfo20"));
		}
		dao.update(pMap, this.tbNm);
		return WebUtils.successResp(null,"操作成功");
	}
	
	/**
	 * 删除
	 * @param pMap
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "del")
	@ResponseBody
	public String del(@RequestParam Map<String, Object> pMap, HttpServletRequest request){
		dao.del(String.valueOf(pMap.get("id")), tbNm);
		return WebUtils.successResp(null,"操作成功");
	}
	
	

}
