/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50132
Source Host           : localhost:3306
Source Database       : mydb0029

Target Server Type    : MYSQL
Target Server Version : 50132
File Encoding         : 65001

Date: 2022-03-02 17:16:53
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `class`
-- ----------------------------
DROP TABLE IF EXISTS `class`;
CREATE TABLE `class` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(100) NOT NULL COMMENT '名称',
  `descr` varchar(1000) NOT NULL DEFAULT '' COMMENT '备注',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=57 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of class
-- ----------------------------
INSERT INTO `class` VALUES ('53', '1楼101舍', '啊啊啊啊');
INSERT INTO `class` VALUES ('54', '1楼102舍', '哈哈哈2');
INSERT INTO `class` VALUES ('55', '1楼103舍', '按理说地方');
INSERT INTO `class` VALUES ('56', '2号楼501舍', '阿斯蒂芬阿斯蒂芬三');

-- ----------------------------
-- Table structure for `code`
-- ----------------------------
DROP TABLE IF EXISTS `code`;
CREATE TABLE `code` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `codetype` varchar(40) NOT NULL DEFAULT '' COMMENT '编码组',
  `codedesc` varchar(100) NOT NULL COMMENT '编码组用途',
  `code` varchar(10) NOT NULL COMMENT '编码',
  `name` varchar(100) NOT NULL COMMENT '名称',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=78 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of code
-- ----------------------------
INSERT INTO `code` VALUES ('1', 'C001', '用户类型', '10', '后台管理员');
INSERT INTO `code` VALUES ('3', 'C002', '开启/关闭', 'Y', '开启');
INSERT INTO `code` VALUES ('4', 'C002', '开启/关闭', 'N', '关闭');
INSERT INTO `code` VALUES ('6', 'C003', '是否', 'Y', '是');
INSERT INTO `code` VALUES ('7', 'C003', '是否', 'N', '否');
INSERT INTO `code` VALUES ('11', 'STATUS', '审核状态', '10', '待审批');
INSERT INTO `code` VALUES ('12', 'STATUS', '审核状态', '20', '批准');
INSERT INTO `code` VALUES ('13', 'STATUS', '审核状态', '30', '不批准');
INSERT INTO `code` VALUES ('55', 'C013', '性别', '10', '男');
INSERT INTO `code` VALUES ('56', 'C013', '性别', '20', '女');
INSERT INTO `code` VALUES ('71', 'C018', '维修状态', '10', '等待维修');
INSERT INTO `code` VALUES ('72', 'C018', '维修状态', '20', '维修完成');
INSERT INTO `code` VALUES ('73', 'C001', '用户类型', '30', '宿舍管理员');
INSERT INTO `code` VALUES ('74', 'C001', '用户类型', '20', '学生');
INSERT INTO `code` VALUES ('75', 'C005', '宿舍调换申请状态', '10', '申请中');
INSERT INTO `code` VALUES ('76', 'C005', '宿舍调换申请状态', '20', '审批通过');
INSERT INTO `code` VALUES ('77', 'C005', '宿舍调换申请状态', '30', '审批不通过');

-- ----------------------------
-- Table structure for `notice`
-- ----------------------------
DROP TABLE IF EXISTS `notice`;
CREATE TABLE `notice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `content` text,
  `iuid` int(11) DEFAULT NULL,
  `itime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of notice
-- ----------------------------
INSERT INTO `notice` VALUES ('1', '45674567', '4567456745674567', '1', '2022-02-15 14:10:50');
INSERT INTO `notice` VALUES ('3', '疫情结束了', '开学吧开学吧开学吧开学吧开学吧开学吧开学吧开学吧开学吧开学吧开学吧开学吧开学吧开学吧开学吧', '1', '2022-02-15 14:10:50');
INSERT INTO `notice` VALUES ('4', '开学啦', '开学那两款京东方啊拉克丝地方', '1', '2022-02-18 21:11:12');

-- ----------------------------
-- Table structure for `product`
-- ----------------------------
DROP TABLE IF EXISTS `product`;
CREATE TABLE `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL COMMENT '名称',
  `icon` varchar(255) DEFAULT NULL COMMENT '图片',
  `cid` int(11) DEFAULT NULL COMMENT '所属宿舍',
  `content` text COMMENT '说明',
  `num` int(11) DEFAULT '0' COMMENT '数量',
  `status` varchar(10) DEFAULT NULL COMMENT '状态',
  `yn` char(1) DEFAULT 'Y' COMMENT '是否有效',
  `iuid` int(11) DEFAULT NULL COMMENT '添加人',
  `itime` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of product
-- ----------------------------
INSERT INTO `product` VALUES ('1', '桌子', '../../upload/15886614136641.jpg', '53', null, '2', null, 'Y', '55', '2022-02-15 14:10:50');
INSERT INTO `product` VALUES ('2', '456', '../../upload/15886617177825.jpg', '53', null, '4567', null, 'N', '55', '2022-02-15 14:10:50');
INSERT INTO `product` VALUES ('3', '4567', '../../upload/15886618620624.jpg', '54', null, '4567', null, 'N', '55', '2022-02-15 14:10:50');
INSERT INTO `product` VALUES ('4', '花盆', '../../upload/15886660871643.jpg', '53', null, '4', null, 'Y', '55', '2022-02-15 14:10:50');
INSERT INTO `product` VALUES ('5', '桌子', '../../upload/16136559123784.jpg', '55', null, '2', null, 'Y', '55', '2022-02-18 21:45:19');

-- ----------------------------
-- Table structure for `qingjia`
-- ----------------------------
DROP TABLE IF EXISTS `qingjia`;
CREATE TABLE `qingjia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ymd` varchar(20) DEFAULT NULL,
  `classid` varchar(255) DEFAULT NULL,
  `descr` varchar(1000) DEFAULT NULL,
  `iuid` int(11) DEFAULT NULL,
  `itime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(10) DEFAULT '10' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of qingjia
-- ----------------------------
INSERT INTO `qingjia` VALUES ('7', '2022-02-16', '53', '家里有事请假一天', '56', '2022-02-16 18:40:25', '20');
INSERT INTO `qingjia` VALUES ('8', '2022-02-19', '53', '休息', '56', '2022-02-18 21:49:11', '20');
INSERT INTO `qingjia` VALUES ('9', '2022-02-20', '55', 'asdf', '56', '2022-02-18 21:54:23', '10');

-- ----------------------------
-- Table structure for `repair`
-- ----------------------------
DROP TABLE IF EXISTS `repair`;
CREATE TABLE `repair` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `classid` varchar(20) NOT NULL DEFAULT '' COMMENT '宿舍编号',
  `name` varchar(255) NOT NULL COMMENT '报修内容',
  `status` varchar(10) NOT NULL COMMENT '报修状态',
  `appraise` varchar(255) DEFAULT NULL COMMENT '报修评价',
  `iuid` int(11) DEFAULT NULL COMMENT '添加人',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=65 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of repair
-- ----------------------------
INSERT INTO `repair` VALUES ('54', '54', '室内灯不亮了', '20', '啪啪啪啪1', '58');
INSERT INTO `repair` VALUES ('55', '54', '刘医生', '20', '服务范围', '58');
INSERT INTO `repair` VALUES ('56', '54', '厕所', '20', '好评', '58');
INSERT INTO `repair` VALUES ('57', '54', '门锁坏了', '20', '354364563456', '58');
INSERT INTO `repair` VALUES ('58', '54', '点灯坏了', '20', null, '57');
INSERT INTO `repair` VALUES ('59', '53', '门锁坏了', '20', '五星好评', '57');
INSERT INTO `repair` VALUES ('60', '53', '床坏了，吱吱响', '20', '没修好呢', '59');
INSERT INTO `repair` VALUES ('61', '53', '窗户玻璃坏了， 不小心打坏了', '20', '技术高超', '59');
INSERT INTO `repair` VALUES ('62', '53', 'asdfasd', '10', null, '56');
INSERT INTO `repair` VALUES ('63', '53', '桌子坏了', '20', '五星好评', '60');
INSERT INTO `repair` VALUES ('64', '53', '灯不亮了', '20', '五星好评', '56');

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL COMMENT '昵称',
  `login` varchar(40) NOT NULL COMMENT '登录账号',
  `pwd` varchar(40) NOT NULL COMMENT '登陆密码',
  `utype` varchar(10) NOT NULL COMMENT '用户类型(C001)',
  `yn` char(1) DEFAULT 'Y',
  `icon` varchar(255) DEFAULT NULL COMMENT '头像',
  `classid` varchar(10) DEFAULT NULL COMMENT '所在宿舍',
  `sex` varchar(10) DEFAULT NULL COMMENT '性别',
  `age` varchar(10) DEFAULT NULL COMMENT '年龄',
  `tel` varchar(50) DEFAULT NULL COMMENT '电话',
  `addr` varchar(50) DEFAULT NULL COMMENT '地址',
  `email` varchar(50) DEFAULT NULL,
  `endyn` char(1) DEFAULT 'N' COMMENT '是否毕业',
  `classidnew` varchar(10) DEFAULT NULL COMMENT '申请调换宿舍',
  `status` varchar(10) DEFAULT '10' COMMENT '状态',
  `descr` varchar(255) DEFAULT NULL COMMENT '调换原因',
  `itime` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `idx_login` (`login`)
) ENGINE=MyISAM AUTO_INCREMENT=61 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', '超级管理员', 'admin', '111111', '10', 'Y', '../../upload/123.jpeg', '53', '10', null, '13899922888', '36', '3223322', 'N', null, null, null, null);
INSERT INTO `user` VALUES ('55', '宿管1【宿管】', 'SG01', '111111', '30', 'Y', '../../upload/123.jpeg', '53', '10', null, '13799990000', '中国北京', '1231@qq.com', 'N', null, null, null, null);
INSERT INTO `user` VALUES ('56', '张三【学生】', 'XS01', '111111', '20', 'Y', '../../upload/16136529002854.jpg', '56', '10', null, '135555555555', '12312', '1213@ww.asd', 'N', '56', '20', '我就是想去', null);
INSERT INTO `user` VALUES ('57', '李四【学生】', 'XS02', '111111', '20', 'Y', '../../upload/123.jpeg', '54', '10', null, '13799990000', '中国北京', '123331@qq.com', 'N', null, null, null, null);
INSERT INTO `user` VALUES ('58', '王五【学生】', 'XS03', '111111', '20', 'Y', '', '53', '20', null, '135555555555', '4567', '4567', 'N', null, null, null, null);
INSERT INTO `user` VALUES ('59', '赵六【学生】', 'XS04', '111111', '20', 'Y', '../../upload/15871921375054.jpg', '53', '10', null, '138111111122', '123123123', '13123@ww2@fs', 'N', null, null, null, null);
INSERT INTO `user` VALUES ('60', '测试[学生]', 'XS005', '111111', '20', 'Y', '../../upload/15886658923212.jpg', '53', '10', null, '13811122222', '阿斯顿发发骚', '1213@ww.asd', 'N', '53', '20', '我爸是李刚', null);

-- ----------------------------
-- Table structure for `visitor`
-- ----------------------------
DROP TABLE IF EXISTS `visitor`;
CREATE TABLE `visitor` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `no` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL COMMENT '受访人',
  `vname` varchar(50) NOT NULL COMMENT '访客',
  `rel` varchar(50) DEFAULT NULL COMMENT '关系',
  `starttime` varchar(30) DEFAULT NULL,
  `endtime` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=64 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of visitor
-- ----------------------------
INSERT INTO `visitor` VALUES ('61', '53', '张三', '李四', '朋友', '2022-02-13 00:00:00', '2022-02-05 12:00:00');
INSERT INTO `visitor` VALUES ('62', '53', '测试', '李刚', '父子', '2022-02-05 13:00:00', '2022-02-05 17:00:00');
INSERT INTO `visitor` VALUES ('63', '53', '张三', '张大伞', '父子', '2022-02-18 00:00:00', '2022-03-11 00:00:00');

-- ----------------------------
-- Table structure for `wenda`
-- ----------------------------
DROP TABLE IF EXISTS `wenda`;
CREATE TABLE `wenda` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(10) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `sdescr` varchar(1000) DEFAULT NULL COMMENT '问',
  `edescr` varchar(1000) DEFAULT NULL COMMENT '答',
  `status` varchar(20) DEFAULT NULL,
  `stime` varchar(40) DEFAULT NULL,
  `etime` varchar(40) DEFAULT NULL,
  `iuid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wenda
-- ----------------------------
INSERT INTO `wenda` VALUES ('1', null, '按理说地方', '埃里克森多级发阿斯兰的看法', '非常感谢宝贵意见', '已回复', '2022-02-05 15:01:30', '2022-02-05 15:03:00', '55');
INSERT INTO `wenda` VALUES ('2', null, '建议建议', '建议建议建议建议建议建议建议建议建议建议', '感谢宝贵意见', '已回复', '2022-02-05 16:10:56', '2022-02-05 16:12:18', '60');
INSERT INTO `wenda` VALUES ('3', null, '服务效率希望提升', '希望点灯坏了赶快修', '感谢反馈', '已回复', '2022-02-18 21:48:38', '2022-02-18 21:49:43', '56');
